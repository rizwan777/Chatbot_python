from nltk.tokenize import word_tokenize,sent_tokenize

req ="python"
data ="hello there, whats up. the weather is great and python is awesome. tell me the weather of rizhao"
check = []
a = word_tokenize(data)

for i in a:
    check.append(i)

print(sent_tokenize(data))
print(word_tokenize(data))
print(check)
