import requests
import json

#api_address = "http://api.openweathermap.org/data/2.5/weather?appid=d4514c045821c9e1353b99cef776cae5&q="

#app = "http://api.openweathermap.org/data/2.5/weather?q="
#app_key ="&appid=d4514c045821c9e1353b99cef776cae5"
city = input("Enter the city name")
url1 = ("http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=d4514c045821c9e1353b99cef776cae5")
#url= str(app + city + app_key)
send = requests.get(url1).json()
data1 = json.dumps(str(send))
print(data1)