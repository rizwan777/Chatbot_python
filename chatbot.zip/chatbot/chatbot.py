from chatterbot.trainers import ListTrainer
from chatterbot import ChatBot
from flask import  Flask , jsonify
from flask_restful import  Resource, Api
import json
import requests

'''
                    this is chatbot web api program you can access it any where with android, ios or any other application
                    this is basic idea how chatbot works 
                    note: for fast response you must have best GPU.
'''
app = Flask(__name__)
api = Api(app)

'''
this helps you to train data to chatbot by using  "localhost:5000/chat/"
'''
class LoadData(Resource):
    def get(self):
        bot = ChatBot('Test')
        conv1 = open('chat.txt','r').readlines()
        conv = open('weather.txt', 'r').readlines()
        """
        you can used for loop with OS module by importing path of directory 
        and train the chatbot with multiple file by defining for loop 
        but sometimes os path doest match for some reasons so everyone cant to
        readfile easily. so it easy way i used to times to readfile seprately. 
        """
        bot.set_trainer(ListTrainer)
        bot.train(conv)
        bot.train(conv1)
        return ('Training Data Applied..!')


'''
this helps you to train data to chatbot by using  "localhost:5000/chat/query/whats your name"
in there string you pass as question after the "query/(question)"
you can check it by passing question in browser "localhost:5000/chat/query/(question)"  <----question enter hear

this gives you resoponse in json format data as replay of question.
'''

class ChatNow(Resource):
    def get(self, req, method =['GET']):
       # Parm_req = request.args.get('req',type= str)

        bot = ChatBot('Test')
        response = bot.get_response(req)
        #a =str(response)

        result = str(response)


        print('Client   :', req)
        print('Server   :', response)
        return jsonify({ "result" : result } )



"""
hear i added third party api to access data of weather of any city you can also sign in openweathermap.org
and get your appid key to use. and just replace it with your id key hear below code.
find this in code----->>>    "&appid=d4514c045821c9e1353b99cef776cae5"     <<<-----and change it with your key.
then you can access the third party API in json format
by simple accessing your web api ---> localhost:5000/weather/query/(city)  <---just add any city name you want to find.
for example------> localhost:5000/weather/query/surat
                    localhost:5000/weather/query/surat,IN   <---for more perfect and accurate result used country code
"""


class Weather(Resource):
  def get(self, city, methods =['GET']):
    area = city
    url1 = ("http://api.openweathermap.org/data/2.5/weather?q=" + area + "&appid=d4514c045821c9e1353b99cef776cae5")
    #url= str(app + city + app_key)
    send = requests.get(url1).json()
    data1 = json.dumps(str(send))
    print(data1)
    return jsonify({'result':data1})


api.add_resource(LoadData,'/chat');
api.add_resource(ChatNow,"/chat/query/<req>")
api.add_resource(Weather,"/weather/query/<city>")
if __name__ == '__main__':
     app.run(debug=True)